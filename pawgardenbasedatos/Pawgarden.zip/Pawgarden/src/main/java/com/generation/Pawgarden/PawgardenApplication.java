package com.generation.Pawgarden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawgardenApplication {

	public static void main(String[] args) {
		SpringApplication.run(PawgardenApplication.class, args);
	}

}
