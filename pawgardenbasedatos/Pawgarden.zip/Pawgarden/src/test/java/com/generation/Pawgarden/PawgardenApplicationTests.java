package com.generation.Pawgarden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawgardenApplicationTests {

	@Test
	void contextLoads() {
	}

}
